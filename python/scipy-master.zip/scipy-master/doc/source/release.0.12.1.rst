.. include:: ../release/0.12.1-notes.rst
