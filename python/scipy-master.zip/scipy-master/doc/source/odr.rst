.. automodule:: scipy.odr
