.. include:: ../release/0.7.2-notes.rst
