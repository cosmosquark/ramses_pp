.. include:: ../release/0.11.0-notes.rst
