.. automodule:: scipy.linalg.interpolative
