
Plotting
========

.. toctree::
   :maxdepth: 2

.. automodule:: pynbody.plot.gas
   :members:

.. automodule:: pynbody.plot.generic
   :members:

.. automodule:: pynbody.plot.metals
   :members:

.. automodule:: pynbody.plot.profile
   :members:

.. automodule:: pynbody.plot.sph
   :members:

.. automodule:: pynbody.plot.stars
   :members:

.. automodule:: pynbody.plot.util
   :members:

