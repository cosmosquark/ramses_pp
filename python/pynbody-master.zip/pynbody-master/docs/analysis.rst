
Analysis
========


.. automodule:: pynbody.analysis.angmom
   :members:

.. automodule:: pynbody.analysis.cosmology
   :members:

.. automodule:: pynbody.analysis.decomp
   :members:

.. automodule:: pynbody.analysis.gravity
   :members:

.. automodule:: pynbody.analysis.halo
   :members:

.. automodule:: pynbody.analysis.hmf
   :members:

.. automodule:: pynbody.analysis.ionfrac
   :members:

.. automodule:: pynbody.analysis.luminosity
   :members:

.. automodule:: pynbody.analysis.pkdgrav_cosmo
   :members:

.. automodule:: pynbody.analysis.profile
   :members:

.. automodule:: pynbody.analysis.ramses_util
   :members:
