.. essential pynbody modules

Essential Framework Modules
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pynbody.array
   :members:

.. automodule:: pynbody.simdict
   :members:

.. automodule:: pynbody.family
   :members:

.. automodule:: pynbody.snapshot
   :members:

.. automodule:: pynbody.units
   :members:

.. automodule:: pynbody.util
   :members:

